create function get_relname(t text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
  SELECT pg_catalog.quote_ident(a[array_upper(a, 1)])
  FROM pg_catalog.parse_ident(t) AS a;
$$;

alter function get_relname(text) owner to postgres;

