create function pseudo_country(seed anyelement, salt text DEFAULT NULL::text) returns text
    stable
    security definer
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT COALESCE(val,anon.notice_if_not_init())
  FROM anon.country
  WHERE oid = anon.projection_to_oid(
    seed,
    COALESCE(salt, pg_catalog.current_setting('anon.salt')),
    (SELECT MAX(oid) FROM anon.country)
  );
$$;

alter function pseudo_country(anyelement, text) owner to postgres;

