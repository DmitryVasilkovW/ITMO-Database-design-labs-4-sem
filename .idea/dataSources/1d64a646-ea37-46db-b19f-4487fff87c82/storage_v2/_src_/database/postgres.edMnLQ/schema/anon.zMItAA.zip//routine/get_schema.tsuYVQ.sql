create function get_schema(t text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
  SELECT pg_catalog.quote_ident(a[array_upper(a, 1)-1])
  FROM pg_catalog.parse_ident(t) AS a;
$$;

alter function get_schema(text) owner to postgres;

