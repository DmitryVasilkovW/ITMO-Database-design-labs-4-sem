create view pg_masked_roles
            (rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin, rolreplication, rolconnlimit,
             rolpassword, rolvaliduntil, rolbypassrls, rolconfig, oid, hasmask)
as
SELECT r.rolname,
       r.rolsuper,
       r.rolinherit,
       r.rolcreaterole,
       r.rolcreatedb,
       r.rolcanlogin,
       r.rolreplication,
       r.rolconnlimit,
       r.rolpassword,
       r.rolvaliduntil,
       r.rolbypassrls,
       r.rolconfig,
       r.oid,
       anon.hasmask(r.oid::regrole) AS hasmask
FROM pg_roles r;

alter table pg_masked_roles
    owner to postgres;

