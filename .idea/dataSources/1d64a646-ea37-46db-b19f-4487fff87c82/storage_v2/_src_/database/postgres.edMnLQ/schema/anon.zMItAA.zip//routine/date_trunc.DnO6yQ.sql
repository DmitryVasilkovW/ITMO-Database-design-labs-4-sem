create function date_trunc(text, interval) returns interval
    parallel safe
    language sql
as
$$ SELECT pg_catalog.date_trunc($1,$2); $$;

alter function date_trunc(text, interval) owner to postgres;

