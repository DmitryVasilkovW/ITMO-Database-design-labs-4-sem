create function random_date() returns timestamp with time zone
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT anon.random_date_between('1900-01-01'::timestamp with time zone,now());
$$;

alter function random_date() owner to postgres;

