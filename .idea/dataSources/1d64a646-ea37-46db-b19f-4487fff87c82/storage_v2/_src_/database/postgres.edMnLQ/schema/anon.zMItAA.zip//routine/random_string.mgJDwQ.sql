create function random_string(l integer) returns text
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT array_to_string(
    array(
        select substr('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
                      ((random()*(36-1)+1)::integer)
                      ,1)
        from generate_series(1,l)
    ),''
  );
$$;

alter function random_string(integer) owner to postgres;

