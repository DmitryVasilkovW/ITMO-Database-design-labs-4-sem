create function mask_update() returns boolean
    security definer
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
  -- Check if dynamic masking is enabled
  PERFORM nspname
  FROM pg_catalog.pg_namespace
  WHERE nspname = pg_catalog.current_setting('anon.maskschema', true)::NAME;

  IF NOT FOUND THEN
    -- Dynamic masking is disabled, no need to go further
    RETURN FALSE;
  END IF;

  --
  -- Until Postgres 16, users could manually transform a table into a view
  -- using a basic CREATE RULE statement. Placing a masking rule on a view is
  -- not supported, however a very stubborn user could try to create a table,
  -- put a mask on it and then transform the table into a view. In that case,
  -- the mask_update process is stopped immediatly
  --
  -- https://github.com/postgres/postgres/commit/b23cd185fd5410e5204683933f848d4583e34b35
  --
  PERFORM c.oid
  FROM pg_catalog.pg_class c
  JOIN anon.pg_masking_rules mr ON c.oid = mr.attrelid
  WHERE c.relkind='v';

  IF FOUND THEN
    RAISE EXCePTION 'Masking a view is not supported.';
  END IF;

  -- Walk through all tables in the source schema
  -- and build a dynamic masking view
  PERFORM anon.mask_create_view(oid)
  FROM pg_catalog.pg_class
  WHERE relnamespace=quote_ident(pg_catalog.current_setting('anon.sourceschema'))::REGNAMESPACE
  AND relkind IN ('r','p','f') -- relations or partitions or foreign tables
  ;

  -- Walk through all masked roles and apply the restrictions
  PERFORM anon.mask_role(oid::REGROLE)
  FROM pg_catalog.pg_roles
  WHERE anon.hasmask(oid::REGROLE);

  RETURN TRUE;
END
$$;

alter function mask_update() owner to postgres;

