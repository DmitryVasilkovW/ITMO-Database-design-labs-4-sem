create function anonymize_table(tablename regclass) returns boolean
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  sql TEXT;
  ratio TEXT;
BEGIN
  SELECT anon.get_tablesample_ratio(tablename::OID) INTO ratio;
  IF ratio IS NOT NULL
  THEN
      -- If there's a tablesample ratio then we can't simply update the table.
      -- we have to rewrite it completely.
      -- NOTE: If the table has a foregin Key, this will likely fail
      RAISE DEBUG 'Anonymize table % with TRUNCATE/INSERT', tablename;
      EXECUTE format(
                'CREATE TEMPORARY TABLE "anon_swap_%s" AS %s',
                tablename::OID,
                anon.mask_select(tablename::OID)
              );
      EXECUTE format('TRUNCATE TABLE %s', tablename);
      EXECUTE format(
                'INSERT INTO %s SELECT * FROM "anon_swap_%s"',
                tablename,
                tablename::OID
              );
      EXECUTE format('DROP TABLE "anon_swap_%s"',tablename::OID);
      RETURN TRUE;
  ELSE
      -- If no sampling is required, we use UPDATE which is a safer approach
      SELECT string_agg(
                anon.build_anonymize_column_assignment(tablename, attname),
                ','
              )
      INTO sql
      FROM anon.pg_masking_rules
      WHERE attrelid::regclass = tablename;

      IF sql != '' THEN
        RAISE DEBUG 'Anonymize table % with %', tablename, sql;
        EXECUTE format('UPDATE %s SET %s', tablename, sql);
        RETURN TRUE;
      END IF;
  END IF;

  RETURN NULL;

EXCEPTION
  WHEN not_null_violation THEN
    RAISE EXCEPTION 'Cannot mask a "NOT NULL" column with a NULL value'
          USING HINT = 'If privacy_by_design is enabled, add a default value to the column';
END;
$$;

alter function anonymize_table(regclass) owner to postgres;

