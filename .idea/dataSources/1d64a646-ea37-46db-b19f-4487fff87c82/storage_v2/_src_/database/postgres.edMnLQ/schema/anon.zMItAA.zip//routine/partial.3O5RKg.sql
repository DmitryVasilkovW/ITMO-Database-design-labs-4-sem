create function partial(ov text, prefix integer, padding text, suffix integer) returns text
    immutable
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT substring(ov FROM 1 FOR prefix)
      || padding
      || substring(ov FROM (length(ov)-suffix+1) FOR suffix);
$$;

alter function partial(text, integer, text, integer) owner to postgres;

