create function random_in_int4range(r int4range) returns integer
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  -- PG12 does not automatically cast the double precision result to INT)
  SELECT CAST( (random()*(upper(r)-lower(r)-1))+lower(r) AS INT);
$$;

alter function random_in_int4range(int4range) owner to postgres;

