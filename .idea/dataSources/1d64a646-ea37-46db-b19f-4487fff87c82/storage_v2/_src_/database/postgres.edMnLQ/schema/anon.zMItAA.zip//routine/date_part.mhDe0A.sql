create function date_part(text, timestamp without time zone) returns double precision
    parallel safe
    language sql
as
$$ SELECT pg_catalog.date_part($1,$2); $$;

alter function date_part(text, timestamp) owner to postgres;

