create function pseudo_city(seed anyelement, salt text DEFAULT NULL::text) returns text
    stable
    security definer
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT COALESCE(val,anon.notice_if_not_init())
  FROM anon.city
  WHERE oid = anon.projection_to_oid(
    seed,
    COALESCE(salt, pg_catalog.current_setting('anon.salt')),
    (SELECT MAX(oid) FROM anon.city)
  );
$$;

alter function pseudo_city(anyelement, text) owner to postgres;

