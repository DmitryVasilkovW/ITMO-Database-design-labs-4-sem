create function date_trunc(text, timestamp with time zone) returns timestamp with time zone
    parallel safe
    language sql
as
$$ SELECT pg_catalog.date_trunc($1,$2); $$;

alter function date_trunc(text, timestamp with time zone) owner to postgres;

