create function length(text) returns integer
    parallel safe
    language sql
as
$$ SELECT pg_catalog.length($1) $$;

alter function length(text) owner to postgres;

