create materialized view mv_cards_hashing as
SELECT cards.client_id,
       md5(cards.credit_card_number::text) AS credit_card_number,
       md5(cards.password)                 AS password,
       md5(cards.cvv::text)                AS cvv
FROM cards;

alter materialized view mv_cards_hashing owner to postgres;

