create function anonymize_database() returns boolean
    SET search_path = ""
    language sql
as
$$
  SELECT bool_or(anon.anonymize_table(t.regclass))
  FROM (
      SELECT distinct attrelid::REGCLASS as regclass
      FROM anon.pg_masking_rules
  ) as t;
$$;

alter function anonymize_database() owner to postgres;

