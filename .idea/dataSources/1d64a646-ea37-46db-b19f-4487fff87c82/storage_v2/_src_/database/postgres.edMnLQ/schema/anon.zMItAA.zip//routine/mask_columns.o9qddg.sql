create function mask_columns(source_relid oid)
    returns TABLE(attname name, masking_filter text, format_type text)
    parallel safe
    SET search_path = ""
    language sql
as
$$
SELECT
  a.attname::NAME, -- explicit cast for PG 9.6
  m.masking_filter,
  m.format_type
FROM pg_catalog.pg_attribute a
LEFT JOIN  anon.pg_masking_rules m
        ON m.attrelid = a.attrelid
        AND m.attname = a.attname
WHERE  a.attrelid = source_relid
AND    a.attnum > 0 -- exclude ctid, cmin, cmax
AND    NOT a.attisdropped
ORDER BY a.attnum
;
$$;

alter function mask_columns(oid) owner to postgres;

