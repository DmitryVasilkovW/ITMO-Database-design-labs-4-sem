create function mask_create_view(relid oid) returns boolean
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  rel_is_view BOOLEAN;
BEGIN
  --
  -- Masking rules on a view is not supported
  --
  SELECT relkind = 'v' INTO rel_is_view
    FROM pg_catalog.pg_class
    WHERE oid=relid;

  IF rel_is_view THEN
    RAISE EXCEPTION 'Masking a view is not supported.';
  END IF;

  EXECUTE format( 'CREATE OR REPLACE VIEW %I.%s AS %s',
                  pg_catalog.current_setting('anon.maskschema'),
                  -- FIXME quote_ident(relid::REGCLASS::TEXT) ?
                  ( SELECT quote_ident(relname)
                    FROM pg_catalog.pg_class
                    WHERE relid = oid
                  ),
                  anon.mask_select(relid)
  );
  RETURN TRUE;
END
$$;

alter function mask_create_view(oid) owner to postgres;

