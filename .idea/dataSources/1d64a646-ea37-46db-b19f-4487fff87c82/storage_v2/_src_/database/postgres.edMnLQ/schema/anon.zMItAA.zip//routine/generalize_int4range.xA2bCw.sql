create function generalize_int4range(val integer, step integer DEFAULT 10) returns int4range
    immutable
    parallel safe
    SET search_path = ""
    language sql
as
$$
SELECT int4range(
    val / step * step,
    ((val / step)+1) * step
  );
$$;

alter function generalize_int4range(integer, integer) owner to postgres;

