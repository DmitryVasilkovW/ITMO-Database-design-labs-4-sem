create function to_char(timestamp with time zone, text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.to_char($1,$2) $$;

alter function to_char(timestamp with time zone, text) owner to postgres;

