create function md5(text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.md5($1) $$;

alter function md5(text) owner to postgres;

