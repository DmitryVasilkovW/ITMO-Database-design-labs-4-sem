create function generalize_tstzrange(val timestamp with time zone, step text DEFAULT 'decade'::text) returns tstzrange
    immutable
    parallel safe
    SET search_path = ""
    language sql
as
$$
WITH lowerbound AS (
  SELECT date_trunc(step, val)::TIMESTAMP WITH TIME ZONE AS d
)
SELECT tstzrange( d, d + ('1 '|| step)::INTERVAL )
FROM lowerbound
;
$$;

alter function generalize_tstzrange(timestamp with time zone, text) owner to postgres;

