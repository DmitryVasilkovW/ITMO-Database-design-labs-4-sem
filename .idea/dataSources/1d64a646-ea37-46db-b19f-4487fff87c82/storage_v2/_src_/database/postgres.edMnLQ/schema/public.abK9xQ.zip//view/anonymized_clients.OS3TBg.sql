create view anonymized_clients(id, name, contact_information) as
SELECT clients.id,
       anon.fake_last_name() AS name,
       anon.fake_email()     AS contact_information
FROM clients;

alter table anonymized_clients
    owner to postgres;

