create function dnoise(noise_value anyelement, noise_range interval) returns anyelement
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  res ALIAS FOR $0;
  ran INTERVAL;
BEGIN
  ran = (2.0 * random() - 1.0) * noise_range;
  SELECT (noise_value + ran)::ANYELEMENT
    INTO res;
  RETURN res;
EXCEPTION
  WHEN datetime_field_overflow THEN
    SELECT (noise_value - ran)::ANYELEMENT
      INTO res;
    RETURN res;
END;
$$;

alter function dnoise(anyelement, interval) owner to postgres;

