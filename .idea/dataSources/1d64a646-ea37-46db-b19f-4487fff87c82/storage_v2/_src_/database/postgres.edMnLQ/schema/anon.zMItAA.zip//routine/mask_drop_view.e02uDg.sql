create function mask_drop_view(relid oid) returns boolean
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
  EXECUTE format('DROP VIEW %I.%s;',
                  pg_catalog.current_setting('anon.maskschema'),
                  -- FIXME quote_ident(relid::REGCLASS::TEXT) ?
                  ( SELECT quote_ident(relname)
                    FROM pg_catalog.pg_class
                    WHERE relid = oid
                  )
  );
  RETURN TRUE;
END
$$;

alter function mask_drop_view(oid) owner to postgres;

