create function ternary(condition boolean, then_val anyelement, else_val anyelement) returns anyelement
    language sql
as
$$
  SELECT CASE WHEN condition THEN then_val ELSE else_val END;
$$;

alter function ternary(boolean, anyelement, anyelement) owner to postgres;

