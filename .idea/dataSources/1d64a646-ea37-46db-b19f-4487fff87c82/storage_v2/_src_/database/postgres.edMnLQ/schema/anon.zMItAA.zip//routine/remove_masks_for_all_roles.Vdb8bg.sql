create function remove_masks_for_all_roles() returns boolean
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT rolname
           FROM anon.pg_masked_roles
           WHERE hasmask
  LOOP
    EXECUTE format('SECURITY LABEL FOR anon ON ROLE %I IS NULL', r.rolname);
  END LOOP;
  RETURN TRUE;
END
$$;

alter function remove_masks_for_all_roles() owner to postgres;

