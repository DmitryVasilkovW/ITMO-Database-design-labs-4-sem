create function column_exists(table_relid regclass, column_name name) returns boolean
    stable
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT count(attname)>0
  FROM pg_catalog.pg_attribute
  WHERE attrelid = table_relid
  AND attnum > 0 -- Ordinary columns are numbered from 1 up
  AND NOT attisdropped
  AND attname = column_name;
$$;

alter function column_exists(regclass, name) owner to postgres;

