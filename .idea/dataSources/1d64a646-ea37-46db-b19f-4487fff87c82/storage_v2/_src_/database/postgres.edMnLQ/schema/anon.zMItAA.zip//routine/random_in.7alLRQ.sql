create function random_in(a anyarray) returns anyelement
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT a[pg_catalog.floor(pg_catalog.random()*array_length(a,1)+1)]
$$;

alter function random_in(anyarray) owner to postgres;

