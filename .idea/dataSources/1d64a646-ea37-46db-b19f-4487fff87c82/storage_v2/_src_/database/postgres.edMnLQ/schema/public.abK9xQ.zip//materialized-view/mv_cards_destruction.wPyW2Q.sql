create materialized view mv_cards_destruction as
SELECT cards.client_id,
       NULL::text AS credit_card_number,
       NULL::text AS password,
       NULL::text AS cvv
FROM cards;

alter materialized view mv_cards_destruction owner to postgres;

