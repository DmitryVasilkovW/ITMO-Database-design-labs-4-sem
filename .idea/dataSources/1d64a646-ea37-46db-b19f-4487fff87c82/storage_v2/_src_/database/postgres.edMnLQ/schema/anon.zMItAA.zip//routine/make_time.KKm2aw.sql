create function make_time(integer, integer, double precision) returns time without time zone
    parallel safe
    language sql
as
$$ SELECT pg_catalog.make_time($1,$2,$3); $$;

alter function make_time(integer, integer, double precision) owner to postgres;

