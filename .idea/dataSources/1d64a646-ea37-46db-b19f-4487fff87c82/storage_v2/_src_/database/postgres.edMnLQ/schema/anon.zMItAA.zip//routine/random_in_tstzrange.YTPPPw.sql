create function random_in_tstzrange(r tstzrange) returns timestamp with time zone
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT  CAST( (random()*(upper(r)-lower(r)))::INTERVAL+lower(r)
          AS TIMESTAMP WITH TIME ZONE);
$$;

alter function random_in_tstzrange(tstzrange) owner to postgres;

