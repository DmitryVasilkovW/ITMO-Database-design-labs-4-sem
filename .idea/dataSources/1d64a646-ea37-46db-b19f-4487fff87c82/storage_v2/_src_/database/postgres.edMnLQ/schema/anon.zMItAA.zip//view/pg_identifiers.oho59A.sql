create view pg_identifiers
            (attrelid, attnum, relname, attname, format_type, col_description, indirect_identifier, priority) as
WITH const AS (SELECT '%(quasi|indirect) identifier%'::text AS pattern_indirect_identifier)
SELECT sl.objoid                                                                     AS attrelid,
       sl.objsubid                                                                   AS attnum,
       c.relname,
       a.attname,
       format_type(a.atttypid, a.atttypmod)                                          AS format_type,
       sl.label                                                                      AS col_description,
       lower(sl.label) ~ similar_to_escape(k.pattern_indirect_identifier, '#'::text) AS indirect_identifier,
       100                                                                           AS priority
FROM const k,
     pg_seclabel sl
         JOIN pg_class c ON sl.classoid = c.tableoid AND sl.objoid = c.oid
         JOIN pg_attribute a ON a.attrelid = c.oid AND sl.objsubid = a.attnum
WHERE a.attnum > 0
  AND NOT a.attisdropped
  AND lower(sl.label) ~ similar_to_escape(k.pattern_indirect_identifier, '#'::text)
  AND sl.provider = current_setting('anon.k_anonymity_provider'::text);

alter table pg_identifiers
    owner to postgres;

