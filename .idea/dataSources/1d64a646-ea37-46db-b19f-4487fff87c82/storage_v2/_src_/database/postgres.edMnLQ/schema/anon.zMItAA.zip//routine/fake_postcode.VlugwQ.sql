create function fake_postcode() returns text
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  WITH random AS (
    SELECT (pg_catalog.random()*last_value)::INTEGER%last_value+1 AS oid
    FROM anon.postcode_oid_seq
  )
  SELECT COALESCE(p.val,anon.notice_if_not_init())
  FROM anon.postcode p
  JOIN random r ON p.oid = r.oid
$$;

alter function fake_postcode() owner to postgres;

