create view anonymized_rental_agreements(id, client_id, car_id, start_date, end_date, total_cost) as
SELECT rental_agreements.id,
       rental_agreements.client_id,
       rental_agreements.car_id,
       random_date('2003-11-11'::date, '2023-11-11'::date)         AS start_date,
       random_date('2003-11-11'::date, '2023-11-11'::date)         AS end_date,
       anon.random_in_numrange(numrange(1::numeric, 239::numeric)) AS total_cost
FROM rental_agreements;

alter table anonymized_rental_agreements
    owner to postgres;

