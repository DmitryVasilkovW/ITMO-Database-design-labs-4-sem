create function date_add(timestamp with time zone, interval) returns timestamp with time zone
    parallel safe
    language sql
as
$$ SELECT $1 + $2; $$;

alter function date_add(timestamp with time zone, interval) owner to postgres;

