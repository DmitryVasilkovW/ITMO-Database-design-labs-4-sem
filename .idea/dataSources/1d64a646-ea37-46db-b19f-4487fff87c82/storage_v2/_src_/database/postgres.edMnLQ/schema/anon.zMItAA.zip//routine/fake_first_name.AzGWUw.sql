create function fake_first_name() returns text
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  WITH random AS (
    SELECT (pg_catalog.random()*last_value)::INTEGER%last_value+1 AS oid
    FROM anon.first_name_oid_seq
  )
  SELECT COALESCE(f.val,anon.notice_if_not_init())
  FROM anon.first_name f
  JOIN random r ON f.oid=r.oid;
$$;

alter function fake_first_name() owner to postgres;

