create function load() returns boolean
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
  RAISE NOTICE 'anon.load() will be deprecated in future versions.'
    USING HINT = 'you should use anon.init() instead.';
  RETURN anon.init();
END;
$$;

alter function load() owner to postgres;

