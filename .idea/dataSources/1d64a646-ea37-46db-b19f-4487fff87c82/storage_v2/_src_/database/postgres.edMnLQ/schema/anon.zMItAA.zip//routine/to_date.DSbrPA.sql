create function to_date(text, text) returns date
    parallel safe
    language sql
as
$$ SELECT pg_catalog.to_date($1,$2) $$;

alter function to_date(text, text) owner to postgres;

