create function fake_iban() returns text
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  WITH random AS (
    SELECT (pg_catalog.random()*last_value)::INTEGER%last_value+1 AS oid
    FROM anon.iban_oid_seq
  )
  SELECT COALESCE(i.val,anon.notice_if_not_init())
  FROM anon.iban i
  JOIN random r ON i.oid = r.oid;
$$;

alter function fake_iban() owner to postgres;

