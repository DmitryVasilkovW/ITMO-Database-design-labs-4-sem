create function stop_dynamic_masking() returns boolean
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  r RECORD;
BEGIN

  SELECT current_setting('is_superuser') = 'on' AS su INTO r;
  IF NOT r.su THEN
    RAISE EXCEPTION 'Only supersusers can stop the dynamic masking engine.';
  END IF;

  -- Walk through all tables in the source schema and drop the masking view
  PERFORM anon.mask_drop_view(oid)
  FROM pg_catalog.pg_class
  WHERE relnamespace=quote_ident(pg_catalog.current_setting('anon.sourceschema'))::REGNAMESPACE
  AND relkind IN ('r','p','f') -- relations or partitions or foreign tables
  ;

  -- Walk through all masked roles and remove their mask
  PERFORM anon.unmask_role(oid::REGROLE)
  FROM pg_catalog.pg_roles
  WHERE anon.hasmask(oid::REGROLE);

  -- Drop the masking schema, it should be empty
  EXECUTE format('DROP SCHEMA %I',
                  pg_catalog.current_setting('anon.maskschema')
  );

  RETURN TRUE;
END
$$;

alter function stop_dynamic_masking() owner to postgres;

