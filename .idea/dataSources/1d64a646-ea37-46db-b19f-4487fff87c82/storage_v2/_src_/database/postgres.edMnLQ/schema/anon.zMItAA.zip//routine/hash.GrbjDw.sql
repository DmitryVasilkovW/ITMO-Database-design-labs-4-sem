create function hash(seed text) returns text
    stable
    strict
    security definer
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT anon.digest(
    seed,
    pg_catalog.current_setting('anon.salt'),
    pg_catalog.current_setting('anon.algorithm')
  );
$$;

alter function hash(text) owner to postgres;

