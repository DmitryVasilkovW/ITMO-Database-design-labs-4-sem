create view clientscarsview(clientid, name, carid, vehicle_model_year) as
SELECT clients.id AS clientid,
       clients.name,
       cars.id    AS carid,
       cars.vehicle_model_year
FROM clients
         JOIN cars ON clients.id = cars.id;

alter table clientscarsview
    owner to lab;

