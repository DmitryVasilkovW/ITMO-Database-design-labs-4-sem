create function anonymize_column(tablename regclass, colname name) returns boolean
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  ratio TEXT;
  sql TEXT;
BEGIN
  SELECT anon.get_tablesample_ratio(tablename::OID) INTO ratio;
  IF ratio IS NOT NULL
  -- We can't apply a tablesample rules to just a column
  THEN
    RAISE NOTICE 'The TABLESAMPLE rule will be ignored.'
      USING HINT = 'Only anonymize_table() and anonymize_database() can apply sampling rules';
  END IF;

  SET CONSTRAINTS ALL DEFERRED;
  sql := anon.build_anonymize_column_assignment(tablename, colname);
  IF sql IS NULL THEN
    RETURN FALSE;
  END IF;
  RAISE DEBUG 'Anonymize % with %', tablename, sql;
  EXECUTE format('UPDATE %s SET %s', tablename, sql);
  RETURN TRUE;
END;
$$;

alter function anonymize_column(regclass, name) owner to postgres;

