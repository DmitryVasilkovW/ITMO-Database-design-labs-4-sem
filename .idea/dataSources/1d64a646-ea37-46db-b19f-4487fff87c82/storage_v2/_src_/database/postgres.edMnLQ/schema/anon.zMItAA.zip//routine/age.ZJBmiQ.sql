create function age(timestamp without time zone) returns interval
    parallel safe
    language sql
as
$$ SELECT pg_catalog.age($1) $$;

alter function age(timestamp) owner to postgres;

