create function age(timestamp without time zone, timestamp without time zone) returns interval
    parallel safe
    language sql
as
$$ SELECT pg_catalog.age($1,$2) $$;

alter function age(timestamp, timestamp) owner to postgres;

