create function notice_if_not_init() returns text
    stable
    parallel safe
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
  IF NOT anon.is_initialized() THEN
    RAISE NOTICE 'The anon extension is not initialized.'
      USING HINT='Use ''SELECT anon.init()'' before running this function';
  END IF;
  RETURN NULL;
END;
$$;

alter function notice_if_not_init() owner to postgres;

