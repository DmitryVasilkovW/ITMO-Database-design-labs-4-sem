create function generalize_numrange(val numeric, step integer DEFAULT 10) returns numrange
    immutable
    parallel safe
    SET search_path = ""
    language sql
as
$$
WITH i AS (
  SELECT anon.generalize_int4range(val::INTEGER,step) as r
)
SELECT numrange(
    lower(i.r)::NUMERIC,
    upper(i.r)::NUMERIC
  )
FROM i
;
$$;

alter function generalize_numrange(numeric, integer) owner to postgres;

