create function version() returns text
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT extversion FROM pg_extension WHERE extname='anon';
$$;

alter function version() owner to postgres;

