create function random_phone(phone_prefix text DEFAULT '0'::text) returns text
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT  phone_prefix
          || CAST(anon.random_int_between(100000000,999999999) AS TEXT)
          AS "phone";
$$;

alter function random_phone(text) owner to postgres;

