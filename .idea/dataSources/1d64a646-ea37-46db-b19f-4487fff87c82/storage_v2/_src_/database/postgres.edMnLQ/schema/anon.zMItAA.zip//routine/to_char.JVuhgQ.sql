create function to_char(numeric, text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.to_char($1,$2) $$;

alter function to_char(numeric, text) owner to postgres;

