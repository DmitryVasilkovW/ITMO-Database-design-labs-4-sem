create function random_date(start_date date, end_date date) returns date
    language plpgsql
as
$$
DECLARE
    time_diff INT;
    random_time INT;
BEGIN
    time_diff := EXTRACT(EPOCH FROM (end_date - start_date));
    random_time := trunc(random() * time_diff);
    RETURN start_date + random_time * INTERVAL '1 second';
END;
$$;

alter function random_date(date, date) owner to postgres;

