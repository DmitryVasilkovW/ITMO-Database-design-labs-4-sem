create view pg_masks
            (attrelid, attnum, relnamespace, relname, attname, format_type, col_description, masking_function,
             masking_value, priority, masking_filter, trusted_schema)
as
SELECT pg_masking_rules.attrelid,
       pg_masking_rules.attnum,
       pg_masking_rules.relnamespace,
       pg_masking_rules.relname,
       pg_masking_rules.attname,
       pg_masking_rules.format_type,
       pg_masking_rules.col_description,
       pg_masking_rules.masking_function,
       pg_masking_rules.masking_value,
       pg_masking_rules.priority,
       pg_masking_rules.masking_filter,
       pg_masking_rules.trusted_schema
FROM anon.pg_masking_rules;

alter table pg_masks
    owner to postgres;

