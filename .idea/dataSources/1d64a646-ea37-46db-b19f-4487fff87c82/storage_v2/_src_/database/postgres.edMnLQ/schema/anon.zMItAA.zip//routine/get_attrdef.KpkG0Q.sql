create function get_attrdef(relid integer, num integer) returns text
    strict
    language sql
as
$$
    SELECT pg_catalog.pg_get_expr(adbin,adrelid)
    FROM pg_catalog.pg_attrdef
    WHERE adrelid=relid
    AND   adnum=num;
$$;

alter function get_attrdef(integer, integer) owner to postgres;

