create function lower(text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.lower($1) $$;

alter function lower(text) owner to postgres;

