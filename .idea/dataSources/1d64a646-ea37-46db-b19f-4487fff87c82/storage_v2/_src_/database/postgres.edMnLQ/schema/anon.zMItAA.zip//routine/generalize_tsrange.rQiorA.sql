create function generalize_tsrange(val timestamp without time zone, step text DEFAULT 'decade'::text) returns tsrange
    immutable
    parallel safe
    SET search_path = ""
    language sql
as
$$
SELECT tsrange(
    date_trunc(step, val)::TIMESTAMP WITHOUT TIME ZONE,
    date_trunc(step, val)::TIMESTAMP WITHOUT TIME ZONE + ('1 '|| step)::INTERVAL
  );
$$;

alter function generalize_tsrange(timestamp, text) owner to postgres;

