create function make_date(integer, integer, integer) returns date
    parallel safe
    language sql
as
$$ SELECT pg_catalog.make_date($1,$2,$3); $$;

alter function make_date(integer, integer, integer) owner to postgres;

