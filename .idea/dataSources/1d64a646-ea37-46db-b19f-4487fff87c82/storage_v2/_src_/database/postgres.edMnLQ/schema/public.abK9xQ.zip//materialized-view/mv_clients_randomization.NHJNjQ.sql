create materialized view mv_clients_randomization as
SELECT clients.id,
       ((48 + floor(random() * 10::double precision)::integer)::text) || clients.name::text                AS name,
       ((48 + floor(random() * 10::double precision)::integer)::text) ||
       clients.contact_information::text                                                                   AS contact_information
FROM clients;

alter materialized view mv_clients_randomization owner to postgres;

