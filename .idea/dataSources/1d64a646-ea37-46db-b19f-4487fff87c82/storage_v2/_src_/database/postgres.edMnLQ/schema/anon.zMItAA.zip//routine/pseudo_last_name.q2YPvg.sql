create function pseudo_last_name(seed anyelement, salt text DEFAULT NULL::text) returns text
    stable
    security definer
    parallel safe
    SET search_path = pg_catalog, pg_temp
    language sql
as
$$
  SELECT COALESCE(val,anon.notice_if_not_init())
  FROM anon.last_name
  WHERE oid = anon.projection_to_oid(
    seed,
    COALESCE(salt, pg_catalog.current_setting('anon.salt')),
    (SELECT max(oid) FROM anon.last_name)
  );
$$;

alter function pseudo_last_name(anyelement, text) owner to postgres;

