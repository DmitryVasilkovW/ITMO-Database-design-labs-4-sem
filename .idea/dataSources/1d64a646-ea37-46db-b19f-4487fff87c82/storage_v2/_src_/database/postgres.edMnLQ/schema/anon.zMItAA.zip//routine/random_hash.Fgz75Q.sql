create function random_hash(seed text) returns text
    strict
    security definer
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT anon.digest(
    seed,
    anon.random_string(6),
    pg_catalog.current_setting('anon.algorithm')
  );
$$;

alter function random_hash(text) owner to postgres;

