create materialized view mv_clients_pseudonymization as
SELECT clients.id,
       md5(clients.name::text)                AS name,
       md5(clients.contact_information::text) AS contact_information
FROM clients;

alter materialized view mv_clients_pseudonymization owner to postgres;

