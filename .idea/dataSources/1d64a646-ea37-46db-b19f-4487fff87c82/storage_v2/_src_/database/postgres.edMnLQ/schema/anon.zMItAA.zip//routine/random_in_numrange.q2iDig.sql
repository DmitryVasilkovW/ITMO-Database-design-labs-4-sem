create function random_in_numrange(r numrange) returns numeric
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT CAST( (random()*(upper(r)-lower(r)))+lower(r) AS NUMERIC);
$$;

alter function random_in_numrange(numrange) owner to postgres;

