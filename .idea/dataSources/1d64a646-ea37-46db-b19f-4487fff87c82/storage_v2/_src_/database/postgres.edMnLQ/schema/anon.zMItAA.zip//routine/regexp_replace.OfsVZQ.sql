create function regexp_replace(text, text, text, text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.regexp_replace($1,$2,$3,$4) $$;

alter function regexp_replace(text, text, text, text) owner to postgres;

