create function load(text) returns boolean
    strict
    SET search_path = ""
    language sql
as
$$
  SELECT anon.init($1);
$$;

alter function load(text) owner to postgres;

