create function random_in_enum(element anyelement) returns anyelement
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT anon.random_in(enum_range(element));
$$;

alter function random_in_enum(anyelement) owner to postgres;

