create function trg_check_trusted_schemas() returns event_trigger
    security definer
    parallel safe
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  untrusted_schema TEXT;
BEGIN
  -- This will return nothing if the schema is to be trusted
  SELECT anon.get_function_schema(masking_function)
  INTO untrusted_schema
  FROM anon.pg_masking_rules
  WHERE pg_catalog.current_setting('anon.restrict_to_trusted_schemas')::BOOLEAN
  AND masking_function IS NOT NULL
  AND NOT trusted_schema
  LIMIT 1;

  IF untrusted_schema = '' THEN
    RAISE 'The schema of the masking filter must be defined'
      USING HINT = 'Check the anon.restrict_to_trusted_schemas parameter';
  ELSIF pg_catalog.length(untrusted_schema) > 0 THEN
    RAISE '% is not a trusted schema.', untrusted_schema
      USING HINT = 'You must add a TRUSTED security label to this schema.';
  END IF;
END;
$$;

alter function trg_check_trusted_schemas() owner to postgres;

