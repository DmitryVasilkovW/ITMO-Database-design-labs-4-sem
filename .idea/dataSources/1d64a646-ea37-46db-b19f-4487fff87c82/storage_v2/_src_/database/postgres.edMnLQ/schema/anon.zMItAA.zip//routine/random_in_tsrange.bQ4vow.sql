create function random_in_tsrange(r tsrange) returns timestamp without time zone
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT  CAST( (random()*(upper(r)-lower(r)))::INTERVAL+lower(r)
          AS TIMESTAMP WITHOUT TIME ZONE);
$$;

alter function random_in_tsrange(tsrange) owner to postgres;

