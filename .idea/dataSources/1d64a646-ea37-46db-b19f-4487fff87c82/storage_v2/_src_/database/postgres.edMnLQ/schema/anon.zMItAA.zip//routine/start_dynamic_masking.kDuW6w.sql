create function start_dynamic_masking(autoload boolean DEFAULT true) returns boolean
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  r RECORD;
BEGIN

  SELECT current_setting('is_superuser') = 'on' AS su INTO r;
  IF NOT r.su THEN
    RAISE EXCEPTION 'Only supersusers can start the dynamic masking engine.';
  END IF;

  -- Load faking data
  SELECT anon.is_initialized() AS init INTO r;
  IF NOT autoload THEN
    RAISE DEBUG 'Autoload is disabled.';
  ELSEIF r.init THEN
    RAISE DEBUG 'Anon extension is already initiliazed.';
  ELSE
    PERFORM anon.init();
  END IF;

  EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I',
                  pg_catalog.current_setting('anon.maskschema')::NAME
  );

  PERFORM anon.mask_update();

  RETURN TRUE;

  EXCEPTION
    WHEN invalid_name THEN
       RAISE EXCEPTION '% is not a valid name',
                        pg_catalog.current_setting('anon.maskschema')::NAME;

END
$$;

alter function start_dynamic_masking(boolean) owner to postgres;

