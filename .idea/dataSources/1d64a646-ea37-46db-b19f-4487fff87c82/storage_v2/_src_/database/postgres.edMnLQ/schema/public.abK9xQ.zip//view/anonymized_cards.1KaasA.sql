create view anonymized_cards(client_id, credit_card_number, password, cvv) as
SELECT cards.client_id,
       anon.random_in_numrange(numrange(1::numeric, 239::numeric))::bigint AS credit_card_number,
       anon.md5(cards.password)                                            AS password,
       anon.md5(cards.cvv::text)                                           AS cvv
FROM cards;

alter table anonymized_cards
    owner to postgres;

