create function random_date(start_date date, end_date date) returns date
    language plpgsql
as
$$
DECLARE
    time_span INT;
    random_date DATE;
BEGIN
    time_span := end_date - start_date;
    random_date := start_date + CAST(trunc(random() * time_span) AS INTEGER);
    RETURN random_date;
END;
$$;

alter function random_date(date, date) owner to postgres;

