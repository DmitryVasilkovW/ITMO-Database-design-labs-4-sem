create function to_number(text, text) returns numeric
    parallel safe
    language sql
as
$$ SELECT pg_catalog.to_number($1,$2) $$;

alter function to_number(text, text) owner to postgres;

