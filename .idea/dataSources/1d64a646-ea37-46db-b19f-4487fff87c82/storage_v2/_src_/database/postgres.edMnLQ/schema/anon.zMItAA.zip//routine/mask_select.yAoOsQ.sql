create function mask_select(relid oid) returns text
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT format(  'SELECT %s FROM %s %s',
                  anon.mask_filters(relid),
                  relid::REGCLASS,
                  anon.get_tablesample_ratio(relid)
  );
$$;

alter function mask_select(oid) owner to postgres;

