create function register_masking_policy(policy text) returns boolean
    strict
    language plpgsql
as
$$
BEGIN
--  PERFORM anon.register_label(policy);
  EXECUTE format('SECURITY LABEL FOR %I ON SCHEMA pg_catalog IS ''TRUSTED'';',
                    policy);
  EXECUTE format('SECURITY LABEL FOR %I ON SCHEMA anon IS ''TRUSTED'';',
                    policy);
  RETURN True;
END;
$$;

alter function register_masking_policy(text) owner to postgres;

