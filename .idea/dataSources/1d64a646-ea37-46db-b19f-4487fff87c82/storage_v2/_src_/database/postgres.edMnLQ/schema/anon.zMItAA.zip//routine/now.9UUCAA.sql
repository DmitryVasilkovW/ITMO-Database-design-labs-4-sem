create function now() returns timestamp with time zone
    parallel safe
    language sql
as
$$ SELECT pg_catalog.now() $$;

alter function now() owner to postgres;

