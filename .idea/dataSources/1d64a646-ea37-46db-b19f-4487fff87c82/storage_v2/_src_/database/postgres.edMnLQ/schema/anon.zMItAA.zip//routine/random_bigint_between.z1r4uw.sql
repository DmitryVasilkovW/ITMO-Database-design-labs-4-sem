create function random_bigint_between(int_start bigint, int_stop bigint) returns bigint
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
    SELECT CAST ( random()*(int_stop-int_start)+int_start AS BIGINT );
$$;

alter function random_bigint_between(bigint, bigint) owner to postgres;

