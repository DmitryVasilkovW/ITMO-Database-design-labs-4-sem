create function substr(text, integer) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.substr($1,$2) $$;

alter function substr(text, integer) owner to postgres;

