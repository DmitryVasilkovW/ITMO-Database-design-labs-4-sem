create function trg_mask_update() returns event_trigger
    SET search_path = ""
    language plpgsql
as
$$
-- SQL Functions cannot return EVENT_TRIGGER,
-- we're forced to write a plpgsql function
BEGIN
  PERFORM anon.mask_update();
END
$$;

alter function trg_mask_update() owner to postgres;

