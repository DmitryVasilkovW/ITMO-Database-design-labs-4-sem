create function random_in_int8range(r int8range) returns bigint
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT CAST( (random()*(upper(r)-lower(r)-1))+lower(r) AS BIGINT);
$$;

alter function random_in_int8range(int8range) owner to postgres;

