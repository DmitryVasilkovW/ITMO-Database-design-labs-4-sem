create function random() returns double precision
    parallel safe
    language sql
as
$$ SELECT pg_catalog.random() $$;

alter function random() owner to postgres;

