create function hasmask(role regrole, masking_policy text DEFAULT 'anon'::text) returns boolean
    stable
    parallel safe
    SET search_path = ""
    language sql
as
$$
SELECT bool_or(m.masked)
FROM (
  -- Rule from SECURITY LABEL
  SELECT label ILIKE 'MASKED' AS masked
  FROM pg_catalog.pg_shseclabel
  WHERE  objoid = role
  AND provider = masking_policy
  UNION
  -- return FALSE if the SELECT above is empty
  SELECT FALSE as masked --
) AS m
$$;

alter function hasmask(regrole, text) owner to postgres;

