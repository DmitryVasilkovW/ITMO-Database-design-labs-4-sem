create function digest(val text, salt text, algorithm text) returns text
    immutable
    strict
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT CASE
    WHEN algorithm = 'md5'
      THEN pg_catalog.md5(concat(val,salt))
    WHEN algorithm = 'sha224'
      THEN pg_catalog.encode(pg_catalog.sha224(concat(val,salt)::BYTEA),'hex')
    WHEN algorithm = 'sha256'
      THEN pg_catalog.encode(pg_catalog.sha256(concat(val,salt)::BYTEA),'hex')
    WHEN algorithm = 'sha384'
      THEN pg_catalog.encode(pg_catalog.sha384(concat(val,salt)::BYTEA),'hex')
    WHEN algorithm = 'sha512'
      THEN pg_catalog.encode(pg_catalog.sha512(concat(val,salt)::BYTEA),'hex')
    ELSE NULL
    END
$$;

alter function digest(text, text, text) owner to postgres;

