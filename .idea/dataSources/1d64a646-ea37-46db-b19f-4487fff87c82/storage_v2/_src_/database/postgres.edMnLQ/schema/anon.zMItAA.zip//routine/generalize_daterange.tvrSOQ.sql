create function generalize_daterange(val date, step text DEFAULT 'decade'::text) returns daterange
    immutable
    parallel safe
    SET search_path = ""
    language sql
as
$$
SELECT daterange(
    date_trunc(step, val)::DATE,
    (date_trunc(step, val) + ('1 '|| step)::INTERVAL)::DATE
  );
$$;

alter function generalize_daterange(date, text) owner to postgres;

