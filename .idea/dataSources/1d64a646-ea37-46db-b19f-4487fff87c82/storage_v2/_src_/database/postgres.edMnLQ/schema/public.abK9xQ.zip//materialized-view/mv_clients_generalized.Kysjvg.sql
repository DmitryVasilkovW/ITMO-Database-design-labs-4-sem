create materialized view mv_clients_generalized as
SELECT clients.id,
       "substring"(clients.name::text, 1, 1)                AS name,
       "substring"(clients.contact_information::text, 1, 5) AS contact_information
FROM clients;

alter materialized view mv_clients_generalized owner to postgres;

