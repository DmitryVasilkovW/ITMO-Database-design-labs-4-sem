create function concat(text, text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.concat($1,$2) $$;

alter function concat(text, text) owner to postgres;

