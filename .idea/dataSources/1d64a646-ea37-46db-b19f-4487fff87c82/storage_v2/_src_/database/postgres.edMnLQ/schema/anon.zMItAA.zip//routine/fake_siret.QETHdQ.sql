create function fake_siret() returns text
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  WITH random AS (
    SELECT (pg_catalog.random()*last_value)::INTEGER%last_value+1 AS oid
    FROM anon.siret_oid_seq
  )
  SELECT COALESCE(s.val,anon.notice_if_not_init())
  FROM anon.siret s
  JOIN random r ON s.oid = r.oid;
$$;

alter function fake_siret() owner to postgres;

