create materialized view mv_rental_agreements_scrambling as
SELECT rental_agreements.id,
       scramble(rental_agreements.client_id) AS client_id,
       scramble(rental_agreements.car_id)    AS car_id,
       rental_agreements.start_date,
       rental_agreements.end_date,
       rental_agreements.total_cost
FROM rental_agreements;

alter materialized view mv_rental_agreements_scrambling owner to postgres;

