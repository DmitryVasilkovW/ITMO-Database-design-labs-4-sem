create materialized view mv_cards_faking as
SELECT cards.client_id,
       fake_data_generator('Credit_Card_Number'::text) AS credit_card_number,
       fake_data_generator('Password'::text)           AS password,
       fake_data_generator('CVV'::text)                AS cvv
FROM cards;

alter materialized view mv_cards_faking owner to postgres;

