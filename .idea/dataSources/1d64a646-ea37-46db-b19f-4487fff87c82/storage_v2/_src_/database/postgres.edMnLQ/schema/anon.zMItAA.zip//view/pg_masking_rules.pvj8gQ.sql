create view pg_masking_rules
            (attrelid, attnum, relnamespace, relname, attname, format_type, col_description, masking_function,
             masking_value, priority, masking_filter, trusted_schema)
as
WITH const AS (SELECT '%MASKED +WITH +FUNCTION +#"%#(%#)#"%'::text AS pattern_mask_column_function,
                      'MASKED +WITH +VALUE +#"%#" ?'::text         AS pattern_mask_column_value),
     rules_from_default AS (SELECT c.oid                                                                 AS attrelid,
                                   a.attnum,
                                   c.relnamespace::regnamespace                                          AS relnamespace,
                                   c.relname,
                                   a.attname,
                                   format_type(a.atttypid, a.atttypmod)                                  AS format_type,
                                   NULL::text                                                            AS col_description,
                                   NULL::text                                                            AS masking_function,
                                   anon.masking_value_for_column(c.oid, a.attnum::integer,
                                                                 'anon'::text)                           AS masking_value,
                                   0                                                                     AS priority
                            FROM pg_class c
                                     JOIN pg_namespace n ON n.oid = c.relnamespace
                                     JOIN pg_attribute a ON a.attrelid = c.oid
                                     LEFT JOIN pg_attrdef d ON a.attrelid = d.adrelid AND a.attnum = d.adnum
                            WHERE a.attnum > 0
                              AND (n.nspname <> ALL
                                   (ARRAY ['information_schema'::name, 'pg_catalog'::name, 'pg_toast'::name, 'anon'::name]))
                              AND NOT a.attisdropped
                              AND current_setting('anon.privacy_by_default'::text)::boolean),
     rules_from_seclabels AS (SELECT sl.objoid                                                                      AS attrelid,
                                     sl.objsubid                                                                    AS attnum,
                                     c.relnamespace::regnamespace                                                   AS relnamespace,
                                     c.relname,
                                     a.attname,
                                     format_type(a.atttypid, a.atttypmod)                                           AS format_type,
                                     sl.label                                                                       AS col_description,
                                     TRIM(BOTH FROM SUBSTRING(sl.label SIMILAR k.pattern_mask_column_function
                                                              ESCAPE '#'::text))                                    AS masking_function,
                                     TRIM(BOTH FROM SUBSTRING(sl.label SIMILAR k.pattern_mask_column_value
                                                              ESCAPE '#'::text))                                    AS masking_value,
                                     100                                                                            AS priority
                              FROM const k,
                                   pg_seclabel sl
                                       JOIN pg_class c ON sl.classoid = c.tableoid AND sl.objoid = c.oid
                                       JOIN pg_attribute a ON a.attrelid = c.oid AND sl.objsubid = a.attnum
                              WHERE a.attnum > 0
                                AND NOT a.attisdropped
                                AND (sl.label ~ similar_to_escape(k.pattern_mask_column_function, '#'::text) OR
                                     sl.label ~ similar_to_escape(k.pattern_mask_column_value, '#'::text))
                                AND sl.provider = 'anon'::text),
     rules_from_all AS (SELECT rules_from_default.attrelid,
                               rules_from_default.attnum,
                               rules_from_default.relnamespace,
                               rules_from_default.relname,
                               rules_from_default.attname,
                               rules_from_default.format_type,
                               rules_from_default.col_description,
                               rules_from_default.masking_function,
                               rules_from_default.masking_value,
                               rules_from_default.priority
                        FROM rules_from_default
                        UNION
                        SELECT rules_from_seclabels.attrelid,
                               rules_from_seclabels.attnum,
                               rules_from_seclabels.relnamespace,
                               rules_from_seclabels.relname,
                               rules_from_seclabels.attname,
                               rules_from_seclabels.format_type,
                               rules_from_seclabels.col_description,
                               rules_from_seclabels.masking_function,
                               rules_from_seclabels.masking_value,
                               rules_from_seclabels.priority
                        FROM rules_from_seclabels)
SELECT DISTINCT ON (rules_from_all.attrelid, rules_from_all.attnum) rules_from_all.attrelid,
                                                                    rules_from_all.attnum,
                                                                    rules_from_all.relnamespace,
                                                                    rules_from_all.relname,
                                                                    rules_from_all.attname,
                                                                    rules_from_all.format_type,
                                                                    rules_from_all.col_description,
                                                                    rules_from_all.masking_function,
                                                                    rules_from_all.masking_value,
                                                                    rules_from_all.priority,
                                                                    COALESCE(rules_from_all.masking_function,
                                                                             rules_from_all.masking_value)          AS masking_filter,
                                                                    (SELECT count(sl.label) > 0 AND bool_and(sl.label = 'TRUSTED'::text)
                                                                     FROM pg_seclabel sl,
                                                                          anon.get_function_schema(rules_from_all.masking_function) f(schema)
                                                                     WHERE f.schema <> ''::text
                                                                       AND sl.objoid = f.schema::regnamespace::oid) AS trusted_schema
FROM rules_from_all
ORDER BY rules_from_all.attrelid, rules_from_all.attnum, rules_from_all.priority DESC;

alter table pg_masking_rules
    owner to postgres;

grant select on pg_masking_rules to public;

