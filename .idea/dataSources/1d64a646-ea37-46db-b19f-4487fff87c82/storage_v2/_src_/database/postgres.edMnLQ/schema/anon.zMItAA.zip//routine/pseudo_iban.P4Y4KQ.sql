create function pseudo_iban(seed anyelement, salt text DEFAULT NULL::text) returns text
    stable
    security definer
    parallel safe
    SET search_path = ""
    language sql
as
$$
  SELECT COALESCE(val,anon.notice_if_not_init())
  FROM anon.iban
  WHERE oid = anon.projection_to_oid(
    seed,
    COALESCE(salt, pg_catalog.current_setting('anon.salt')),
    (SELECT MAX(oid) FROM anon.iban)
  );
$$;

alter function pseudo_iban(anyelement, text) owner to postgres;

