create function random_int_between(int_start integer, int_stop integer) returns integer
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
    SELECT CAST ( random()*(int_stop-int_start)+int_start AS INTEGER );
$$;

alter function random_int_between(integer, integer) owner to postgres;

