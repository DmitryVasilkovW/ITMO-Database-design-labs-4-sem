create function "right"(text, integer) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.right($1,$2) $$;

alter function "right"(text, integer) owner to postgres;

