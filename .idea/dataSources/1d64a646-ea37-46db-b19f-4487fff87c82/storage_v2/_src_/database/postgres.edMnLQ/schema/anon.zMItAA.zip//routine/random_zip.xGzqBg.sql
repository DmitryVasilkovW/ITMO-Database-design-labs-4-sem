create function random_zip() returns text
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT array_to_string(
         array(
                select substr('0123456789',((random()*(10-1)+1)::integer),1)
                from generate_series(1,5)
            ),''
          );
$$;

alter function random_zip() owner to postgres;

