create function date_trunc(text, timestamp without time zone) returns timestamp without time zone
    parallel safe
    language sql
as
$$ SELECT pg_catalog.date_trunc($1,$2); $$;

alter function date_trunc(text, timestamp) owner to postgres;

