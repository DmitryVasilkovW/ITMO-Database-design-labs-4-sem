create function substr(text, integer, integer) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.substr($1,$2,$3) $$;

alter function substr(text, integer, integer) owner to postgres;

