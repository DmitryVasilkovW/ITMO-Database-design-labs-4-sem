create function generalize_int8range(val bigint, step bigint DEFAULT 10) returns int8range
    immutable
    parallel safe
    SET search_path = ""
    language sql
as
$$
SELECT int8range(
    val / step * step,
    ((val / step)+1) * step
  );
$$;

alter function generalize_int8range(bigint, bigint) owner to postgres;

