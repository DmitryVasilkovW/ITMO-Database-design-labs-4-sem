create function random_in_daterange(r daterange) returns date
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  SELECT CAST(
      (random()*(upper(r)::TIMESTAMP-lower(r)::TIMESTAMP))::INTERVAL
      +lower(r)
      AS DATE
  );
$$;

alter function random_in_daterange(daterange) owner to postgres;

