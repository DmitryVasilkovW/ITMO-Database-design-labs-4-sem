create function unload() returns boolean
    SET search_path = ""
    language sql
as
$$
  SELECT anon.reset()
$$;

alter function unload() owner to postgres;

