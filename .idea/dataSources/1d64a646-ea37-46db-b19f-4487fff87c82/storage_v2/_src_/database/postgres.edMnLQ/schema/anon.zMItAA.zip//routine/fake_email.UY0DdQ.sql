create function fake_email() returns text
    parallel restricted
    SET search_path = ""
    language sql
as
$$
  WITH random AS (
    SELECT (pg_catalog.random()*last_value)::INTEGER%last_value+1 AS oid
    FROM anon.email_oid_seq
  )
  SELECT COALESCE(e.val,anon.notice_if_not_init())
  FROM anon.email e
  JOIN random r ON e.oid=r.oid;
$$;

alter function fake_email() owner to postgres;

