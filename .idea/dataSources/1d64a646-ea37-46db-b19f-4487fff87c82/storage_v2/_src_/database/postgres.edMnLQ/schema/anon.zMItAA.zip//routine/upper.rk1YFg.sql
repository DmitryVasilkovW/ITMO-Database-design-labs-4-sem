create function upper(text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.upper($1) $$;

alter function upper(text) owner to postgres;

