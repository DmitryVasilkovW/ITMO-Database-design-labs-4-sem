create function replace(text, text, text) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.md5($1,$2,$3) $$;

alter function replace(text, text, text) owner to postgres;

