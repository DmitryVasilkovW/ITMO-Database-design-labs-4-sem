create materialized view mv_rental_agreements_noise as
SELECT rental_agreements.id,
       rental_agreements.client_id,
       rental_agreements.car_id,
       rental_agreements.start_date,
       rental_agreements.end_date,
       rental_agreements.total_cost::double precision + random() * 10::double precision AS total_cost
FROM rental_agreements;

alter materialized view mv_rental_agreements_noise owner to postgres;

