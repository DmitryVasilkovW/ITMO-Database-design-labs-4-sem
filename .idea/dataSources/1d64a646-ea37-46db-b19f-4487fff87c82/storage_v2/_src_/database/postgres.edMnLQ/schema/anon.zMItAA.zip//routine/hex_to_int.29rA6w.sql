create function hex_to_int(hexval text) returns integer
    immutable
    strict
    parallel safe
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    result  INT;
BEGIN
    EXECUTE 'SELECT x' || quote_literal(hexval) || '::INT' INTO result;
    RETURN result;
END;
$$;

alter function hex_to_int(text) owner to postgres;

