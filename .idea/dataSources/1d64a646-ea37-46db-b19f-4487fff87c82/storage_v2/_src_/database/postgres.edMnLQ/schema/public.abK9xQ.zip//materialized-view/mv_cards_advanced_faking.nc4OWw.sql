create materialized view mv_cards_advanced_faking as
SELECT cards.client_id,
       advanced_fake_data_generator('Credit_Card_Number'::text) AS credit_card_number,
       advanced_fake_data_generator('Password'::text)           AS password,
       advanced_fake_data_generator('CVV'::text)                AS cvv
FROM cards;

alter materialized view mv_cards_advanced_faking owner to postgres;

