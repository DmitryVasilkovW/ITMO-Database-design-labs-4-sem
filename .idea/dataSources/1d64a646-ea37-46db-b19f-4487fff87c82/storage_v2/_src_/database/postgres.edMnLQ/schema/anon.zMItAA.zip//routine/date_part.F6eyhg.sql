create function date_part(text, interval) returns double precision
    parallel safe
    language sql
as
$$ SELECT pg_catalog.date_part($1,$2); $$;

alter function date_part(text, interval) owner to postgres;

