create function "left"(text, integer) returns text
    parallel safe
    language sql
as
$$ SELECT pg_catalog.left($1,$2) $$;

alter function "left"(text, integer) owner to postgres;

