create function random_date_between(date_start timestamp with time zone, date_end timestamp with time zone) returns timestamp with time zone
    strict
    parallel restricted
    SET search_path = ""
    language sql
as
$$
    SELECT (random()*(date_end-date_start))::interval+date_start;
$$;

alter function random_date_between(timestamp with time zone, timestamp with time zone) owner to postgres;

