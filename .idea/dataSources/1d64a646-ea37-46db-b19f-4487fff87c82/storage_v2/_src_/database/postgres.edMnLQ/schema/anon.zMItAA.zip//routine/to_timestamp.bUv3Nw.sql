create function to_timestamp(text, text) returns timestamp with time zone
    parallel safe
    language sql
as
$$ SELECT pg_catalog.to_timestamp($1,$2) $$;

alter function to_timestamp(text, text) owner to postgres;

